<?php
	session_start();
	$userId = $_SESSION['userId'];
	require_once('mysqli_connect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
	<link href='https://fonts.googleapis.com/css?family=Ubuntu:400,500,700|PT+Sans|Yellowtail' rel='stylesheet' type='text/css'>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
	
	<title>eVerify</title>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-2 leftMenuBar topLeftMenuBar"><h1>eVERIFY</h1></div>
			<div class="col-xs-10 topRightMenuBar">
				<?php

					$userResult = mysqli_query($dbConnection, "SELECT * FROM users WHERE userId = " . $userId);
					$row = mysqli_fetch_array($userResult);
					$firstName = $row['firstName'];
					$lastName = $row['lastName'];

					echo "<h2 id='nameTitle'>" . $firstName . " " . $lastName . "'s account </h2>";
				?>
			</div>
		</div>
		<div class="row mainRow">
			<div class="col-xs-2 leftMenuBar">
				<ul class="leftNav">
					<li><a href="account.php"><span></span>ACCOUNT</a></li>
					<li><a href="addVerification.php"><span></span>NEW VERIFICATION</a></li>
					<li><a href="pendingVerifications.php"><span></span>PENDING VERIFICATIONS</a></li>
					<li><a href="approvedVerifications.php"><span></span>APPROVED VERIFICATIONS</a></li>
					<li class="activeMenuLine"><a class="activeMenuItem" href="declinedVerifications.php"><span></span>DECLINED VERIFICATIONS</a></li>
					<li><a href="index.html"><span></span>LOG OUT</a></li>
				</ul>
			</div>
			<div class="col-xs-10 rightContent">
				<div id="test">
					<h3>Declined verifications</h3>
				</div>
			</div>
		</div>
	</div>
</body>
</html>