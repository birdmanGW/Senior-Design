<?php

	/*
		This page implements the OCR View Document API from HPE Haven OnDemand (https://dev.havenondemand.com/apis/viewdocument#overview) 
		and the HPE Haven OnDemand library for PHP (https://github.com/HPE-Haven-OnDemand/havenondemand-php) (also the 'Demo code 2' illustration).
	
	*/
	session_start();
	include 'havenondemand-php-master\lib\hodclient.php';

	$file = $_FILES['file']['tmp_name'];

	$hodClient = new HODClient("4c7e0506-5e56-4a17-891e-5f7f1fd796e7");

	$parameters = array('file' => $file, 'mode' => "document_scan", 'highlight_expression' => "", 
		"start_tag" => "", "end_tag" => "" );

	$jobID = $hodClient->PostRequest($parameters, HODApps::VIEW_DOCUMENT, REQ_MODE::ASYNC);

	if ($jobID == null){
		echo "<h2 id='imageDataTitle'>Error while reading image. </h2>";
	} else {
	    $response = $hodClient->GetJobResult($jobID);
	    if ($response == null){
	        echo "<h2 id='imageDataTitle'>Error while reading image. </h2>";
	    } else {		       
	    	preg_match_all('/\$\s*([0-9]+[\,]*[0-9]*[\.]*[0-9]*)/', $response, $match);
			$textFile = $match[0];
			$textFile = preg_replace('/\$/', '', $textFile);
			$textFile = preg_replace('/[,]/', '', $textFile);
			$textFile = str_replace(' ', '', $textFile);
			$textFile = array_map(function($value) { return floor($value); }, $textFile);
			$textFile = implode("\r\n", $textFile);
	        $textBlocks = "<div id='imageUpload' style='background-color:white;border:1px solid #E6E6E6;position:relative;overflow-y:scroll;min-height:500px;'>" .
	        $response . "</div>";
	
        	$textBlocks = preg_replace('/\$\s*([0-9]+[\,]*[0-9]*[\.]*[0-9]*)/', '$ <span style=\'color:transparent;text-shadow:0 0 5px rgba(0,0,0,0.5);\'>XXX.XX</span>', $textBlocks);
	        //$textBlocks = preg_replace("/<span class='private'>(.*?)<\/span>/", "<span style='color:transparent;text-shadow:0 0 5px rgba(0,0,0,0.5);'>XXX</span>", $textBlocks);
	        echo $textBlocks;
	            
		    $_SESSION['htmlString'] = $textBlocks;
		    //Create text file and place extracted private data into this file for the pallier encryption program to read and process.
	        $dataFile = fopen("plaintexts.txt", "w");
	        fwrite($dataFile, $textFile);
	        fclose($dataFile);  
	        //Run Java program (Pallier Encryption) on the text file created above and place result (encrypted data) into a session variable.
	        $output = shell_exec("java Pallier"); 
	        $_SESSION['ciphertextData'] = $output;
	        //Delete file with unencrypted private data.
	        unlink("plaintexts.txt");
	    }
	}			
?>