<?php

	session_start();

	require_once('mysqli_connect.php');

	$username = $_POST['username'];
	$password = $_POST['password'];

	$validLogin = false;

	$users = mysqli_query($dbConnection, "SELECT * FROM users");

	while($row = mysqli_fetch_array($users)){

		if($row['email'] == $username && $row['password'] == $password){
			$validLogin = true;
			$_SESSION['userId'] = $row['userId'];
			$_SESSION['loggedIn'] = 'true';
			break;
		}
	}

	if($validLogin){
		header('Location: account.php');
	} else {
		header('Location: index.html');
	}

?>