<?php
	session_start();
	$userId = $_SESSION['userId'];
	require_once('mysqli_connect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
	<link href='https://fonts.googleapis.com/css?family=Ubuntu:400,500,700|PT+Sans|Yellowtail' rel='stylesheet' type='text/css'>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
	<title>eVerify</title>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-2 leftMenuBar topLeftMenuBar"><h1>eVERIFY</h1></div>
			<div class="col-xs-10 topRightMenuBar">
				<?php

					$userResult = mysqli_query($dbConnection, "SELECT * FROM users WHERE userId = " . $userId);
					$row = mysqli_fetch_array($userResult);
					$firstName = $row['firstName'];
					$lastName = $row['lastName'];

					echo "<h2 id='nameTitle'>" . $firstName . " " . $lastName . "'s account </h2>";
				?>
			</div>
		</div>
		<div class="row mainRow">
			<div class="col-xs-2 leftMenuBar">
				<ul class="leftNav">
					<li><a href="account.php"><span></span>ACCOUNT</a></li>
					<li><a href="addVerification.php"><span></span>NEW VERIFICATION</a></li>
					<li class="activeMenuLine"><a class="activeMenuItem" href="pendingVerifications.php"><span></span>PENDING VERIFICATIONS</a></li>
					<li><a href="approvedVerifications.php"><span></span>APPROVED VERIFICATIONS</a></li>
					<li><a href="declinedVerifications.php"><span></span>DECLINED VERIFICATIONS</a></li>
					<li><a href="index.html"><span></span>LOG OUT</a></li>
				</ul>
			</div>
			<div class="col-xs-10 rightContent">			
				<h3>PENDING VERIFICATIONS</h3>
					<?php
						$pendingVerifications = "SELECT * FROM pending_verifications 
													INNER JOIN companies on companies.company_id=pending_verifications.company_id
													INNER JOIN documents on pending_verifications.pending_verification_id=documents.verification_id 
													INNER JOIN encrypted_text on documents.document_id=encrypted_text.document_id 
													WHERE pending_verifications.user_id=" . $userId;

						$pendingVerifications = mysqli_query($dbConnection, $pendingVerifications);
						if($pendingVerifications && mysqli_num_rows($pendingVerifications)){
							echo 	"<table id='pendingVerificationsTable'> 
											<tr>
												<th>DATE UPLOADED</th>
												<th>VERIFIER</th>
												<th>THRESHOLD</th>
												<th>DOCUMENT</th>
											</tr>";
							while($row = mysqli_fetch_array($pendingVerifications)){
								$date = strtotime($row['date']);
								$dateUploaded = date('M d, Y', $date);
								$time = ltrim(date("h:i a", $date), 0);
								$currentDate = date('M d, Y');
								if($currentDate == $dateUploaded){
									$date = "Today at " . $time;
								} else {
									$date = $dateUploaded;
								}
								echo "<tr>"; 
								echo "<td>" . $date . "</td>" . "<td>" . $row['company_name'] . "</td>" . 
									 "<td> $" . number_format($row['threshold']) . "</td>" . "<td>" . 
									 "<span id='documentLink' onclick='openDocumentImage(" . $row['document_id'] . ")'>
									 image</span>" . "</td>"; 
								echo "</tr>";
							}
							echo	"</table>"; 
						} else {
							echo "<p id='noPendingVerificationsNotice'>You have no pending verifications.</p>";
						}
					?>
					<div id='documentContainerHidden'></div>
			</div>
		</div>
	</div>
</body>
</html>