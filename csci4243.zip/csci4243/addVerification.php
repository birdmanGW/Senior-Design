<!-- This page is using icons from font awesome (Font Awesome by Dave Gandy - http://fontawesome.io).  CDN: //maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css  -->
<?php
	/*
		This page implements the OCR Document API from HPE Haven OnDemand (https://dev.havenondemand.com/apis/ocrdocument#overview) 
		and the HPE Haven OnDemand library for PHP (https://github.com/HPE-Haven-OnDemand/havenondemand-php) (also the 'Demo code 2' illustration).
	
	*/
	session_start();
	$userId = $_SESSION['userId'];
	include 'havenondemand-php-master\lib\hodclient.php';
	require_once('mysqli_connect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
	<link href='https://fonts.googleapis.com/css?family=Ubuntu:400,500,700|PT+Sans|Yellowtail' rel='stylesheet' type='text/css'>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="javascript.js"></script>
	<title>eVerify</title>
</head>
<body>
	<div class="container-fluid">
		<div class="overlay"><div><h2>Reading image</h2><img src="images/oie_1279168gr1ClM2.gif"></img></div></div>
		<div class="row">
			<div class="col-xs-2 leftMenuBar topLeftMenuBar"><h1>eVERIFY</h1></div>
			<div class="col-xs-10 topRightMenuBar">
				<?php

					$userResult = mysqli_query($dbConnection, "SELECT * FROM users WHERE user_id = " . $userId);
					$row = mysqli_fetch_array($userResult);
					$firstName = $row['first_name'];
					$lastName = $row['last_name'];

					echo "<h2 id='nameTitle'>" . $firstName . " " . $lastName . "'s account </h2>";
				?>
			</div>
		</div>
		<div class="row mainRow">
			<div class="col-xs-2 leftMenuBar">
				<ul class="leftNav">
					<li><a href="account.php"><span><i class="fa fa-cog" aria-hidden="true"></i></span>ACCOUNT</a></li>
					<li class="activeMenuLine"><a class="activeMenuItem" href="addVerification.php"><span><i class="fa fa-plus" aria-hidden="true"></i></span>NEW VERIFICATION</a></li>
					<li><a href="pendingVerifications.php"><span><i class="fa fa-file-text-o" aria-hidden="true"></i></span>PENDING VERIFICATIONS</a></li>
					<li><a href="approvedVerifications.php"><span><i class="fa fa-check" aria-hidden="true"></i></span>APPROVED VERIFICATIONS</a></li>
					<li><a href="declinedVerifications.php"><span><i class="fa fa-times" aria-hidden="true"></i></span>DECLINED VERIFICATIONS</a></li>
					<li><a href="logOut.php"><span><i class="fa fa-sign-out" aria-hidden="true"></i></span>LOG OUT</a></li>
				</ul>
			</div>
			<div class="col-xs-10 rightContent">		
				<h2>VERIFICATION DETAILS</h2>
				<form id='newVerificationForm' action='submitVerification.php' method='POST' enctype='multipart/form-data'>
					<label>VERIFIER</label>
					<input type="text" name="verifier" id="verifier" autocomplete="off" onkeyup="companySuggestion(this.value)" /><br/>
					<div id="companySuggestionBox">
					</div><br/>
					<label>THRESHOLD</label>
					<input type="text" name="threshold" id="threshold" />
					<input type='file' name='image' id='image' />
					<input type='submit' name='submit' id='uploadDocumentSubmit' />
				</form>

				<button id='uploadDocumentButton'>UPLOAD DOCUMENT</button><br />

				<div id='documentContainer' style='background-color:white;border:1px solid #253240;position:relative;min-height:500px;'>
				<p style="text-align:center;margin-top:18%;font-size:22px;font-weight:500;color:#C8C8C8">NO DOCUMENT</p>
				</div>
				<div id='buttonContainer'><button id='submitVerificationButton'>SUBMIT</button></div>
			</div>
		</div>
		<div class="row footer">
			<div class="col-xs-2 leftMenuBar">&nbsp;</div>
			<div class="col-xs-10 rightContent"></div>
		</div>
	</div>
</body>
</html>