<?php
	/*
		This page implements the OCR Document API from HPE Haven OnDemand (https://dev.havenondemand.com/apis/ocrdocument#overview) 
		and the HPE Haven OnDemand library for PHP (https://github.com/HPE-Haven-OnDemand/havenondemand-php) (also the 'Demo code 2' illustration).
	
	*/
	session_start();
	$userId = $_SESSION['userId'];
	include 'havenondemand-php-master\lib\hodclient.php';
	require_once('mysqli_connect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
	<link href='https://fonts.googleapis.com/css?family=Ubuntu:400,500,700|PT+Sans|Yellowtail' rel='stylesheet' type='text/css'>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
	
	<script src="javascript.js"></script>
	<title>eVerify</title>
</head>
<body>
	<div class="container-fluid">
		<div class="overlay"><div><h2>Reading image</h2><img src=""></img></div></div>
		<div class="row">
			<div class="col-xs-2 leftMenuBar topLeftMenuBar"><h1>eVERIFY</h1></div>
			<div class="col-xs-10 topRightMenuBar">
				<?php

					$userResult = mysqli_query($dbConnection, "SELECT * FROM users WHERE userId = " . $userId);
					$row = mysqli_fetch_array($userResult);
					$firstName = $row['firstName'];
					$lastName = $row['lastName'];

					echo "<h2 id='nameTitle'>" . $firstName . " " . $lastName . "'s account </h2>";
				?>
			</div>
		</div>
		<div class="row mainRow">
			<div class="col-xs-2 leftMenuBar">
				<ul class="leftNav">
					<li><a href="account.php"><span></span>ACCOUNT</a></li>
					<li class="activeMenuLine"><a class="activeMenuItem" href="addVerification.php"><span></span>NEW VERIFICATION</a></li>
					<li><a href="pendingVerifications.php"><span></span>PENDING VERIFICATIONS</a></li>
					<li><a href="approvedVerifications.php"><span></span>APPROVED VERIFICATIONS</a></li>
					<li><a href="declinedVerifications.php"><span></span>DECLINED VERIFICATIONS</a></li>
					<li><a href="index.html"><span></span>LOG OUT</a></li>
				</ul>
			</div>
			<div class="col-xs-10 rightContent">		
				<?php

					echo "<form action='' method='POST' enctype='multipart/form-data'>";
					echo 	"<input type='file' name='image' id='image' />";
					echo 	"<input type='submit' name='submit' id='uploadDocumentSubmit' />";
					echo "</form>";

					echo "<button id='uploadDocumentButton' onclick='clickDocumentImage();'>UPLOAD DOCUMENT</button><br />";

					function readImage($file){

						$hodClient = new HODClient("4c7e0506-5e56-4a17-891e-5f7f1fd796e7");

						$parameters = array('file' => $file, 'mode' => "document_photo");

						$jobID = $hodClient->PostRequest($parameters, HODApps::OCR_DOCUMENT, REQ_MODE::ASYNC);

						if ($jobID == null){
							echo "<h2 id='imageDataTitle'>Error while reading image. </h2>";
						} else {
						    $response = $hodClient->GetJobResult($jobID);
						    if ($response == null){
						        echo "<h2 id='imageDataTitle'>Error while reading image. </h2>";
						    } else {
						        $text = "<h2 id='imageDataTitle'>Image Data: </h2>";
						        $textBlocks = $response->text_block;
						        $numberOfTextBlocks = count($textBlocks);
						        for ($i = 0; $i < $numberOfTextBlocks; $i++) {
						            $block = $textBlocks[$i];
						            $text .= preg_replace("/\n+/", "</br>", $block->text);
						        }

						        echo $text . "<br />";
						        echo "_______________<br />";
						    }
						}
					}

					if(isset($_POST['submit'])){
						$file = $_FILES['image']['tmp_name'];
						readImage($file);
						echo '<script type="text/javascript"> removeOverlay(); </script>';
					}

				?>
			</div>
		</div>
		<div class="row footer">
			<div class="col-xs-2 leftMenuBar">&nbsp;
			</div>
			<div class="col-xs-10 rightContent">
			</div>
		</div>
	</div>
</body>
</html>