
$(document).ready(function(){

	$("#uploadDocumentButton").click(function(){
		$("#image").click();
	});
		
	$("#image").on("change", function(){
		addOverlay();
		$("#uploadDocumentSubmit").click();
	});
});

function addOverlay(){
	$(".overlay").css({"display":"block"});
}

function removeOverlay(){
	$(".overlay").css({"display":"none"});
}


