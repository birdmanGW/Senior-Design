
$(document).ready(function(){

	$("#closeDocumentImage").on("click", function(){
		$("#documentContainerHidden").css({"display":"none"});
	});

	$(".rightContent").click(function(){
		$("#companySuggestionBox").css({"display":"none"});
	});

	$("#uploadDocumentButton").click(function(){
		$("#image").click();
	});
		
	$("#image").on("change", function(){
		addOverlay();
		//$("#uploadDocumentSubmit").click();
		var file = $("#image").prop('files')[0];
		ocrCall(file);
	});

	$("#submitVerificationButton").click(function(){
		if($("#verifier").val() && $("#threshold").val() && $("#image").get(0).files.length !== 0){
			$("#uploadDocumentSubmit").click();
		} else {
			alert("Please fill in all fields and upload a document.");
			return false;
		}
	});

	$("#documentContainerHidden").on("click", "#closeDocumentView", function(){
		$("#documentContainerHidden").css({"display":"none"});
		removeImageUnderlay();
	});

	$(".imageUnderlay").on("click", function(){
		$("#documentContainerHidden").css({"display":"none"});
		removeImageUnderlay();
	});

});

function addOverlay(){
	$(".overlay").css({"display":"block"});
}

function removeOverlay(){
	$(".overlay").css({"display":"none"});
}

function addImageUnderlay(){
	$(".imageUnderlay").css({"display":"block"});
}

function removeImageUnderlay(){
	$(".imageUnderlay").css({"display":"none"});
}

function companySuggestion(company){
	if(company.length == 0){
		document.getElementById("companySuggestionBox").style.display = "none";
	} else {
		if(window.XMLHttpRequest){
          xmlhttp = new XMLHttpRequest();
        } else {
          xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function(){
	        if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
	        	if(xmlhttp.responseText){
	        		document.getElementById("companySuggestionBox").style.display = "block";
	            	document.getElementById("companySuggestionBox").innerHTML = xmlhttp.responseText;
	        	} else {
	        		document.getElementById("companySuggestionBox").innerHTML = "";
	        		document.getElementById("companySuggestionBox").style.display = "none";
	        	}	
	        }
	    }

        xmlhttp.open("GET", "companyQuery.php?company=" + company, true);
        xmlhttp.send();
	}
}

function selectCompanySuggestion(company){
	$("#verifier").val(company);
	$("#companySuggestionBox").css({"display":"none"});
}

function ocrCall(file){
	
	var uploadedDocument = new FormData();
	uploadedDocument.append('file', file);

	$.ajax({
		url: 'readImage.php',
		dataType: 'text',
        contentType: false,
        processData: false,
		data: uploadedDocument,
		type: 'POST',
		success: function(result){
			document.getElementById("documentContainer").innerHTML = result;
			removeOverlay();
		}
	});
}

function openDocumentImage(documentId){
	if(window.XMLHttpRequest){
      xmlhttp = new XMLHttpRequest();
    } else {
      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }	

    xmlhttp.onreadystatechange = function(){
        if(xmlhttp.readyState == 4 && xmlhttp.status == 200){		        	
    		$("#documentContainerHidden").css({"display":"block"});
			document.getElementById("documentContainerHidden").innerHTML = xmlhttp.responseText;
			$("#imageUpload").append("<span id='closeDocumentView' style='position:fixed;left: 86.5%;height: 30px;width: \
				30px;background-color: #E50000;color: white;font-size: 22px;text-align: center;'> \
				&#x2715;</span>");
			$("#closeDocumentView").append("<style>#closeDocumentView:hover{cursor:pointer;}</style>");
			addImageUnderlay();
			$("html, body").css({"overflow":"hidden", "height":"100%"});
        }
    }

    xmlhttp.open("GET", "openImage.php?documentId=" + documentId, true);
    xmlhttp.send();
}


