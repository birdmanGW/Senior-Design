<?php
	session_start();
	$userId = $_SESSION['userId'];
	require_once('mysqli_connect.php');

	if(isset($_POST['verifier']) && isset($_POST['threshold'])){
		$verifier = $_POST['verifier'];
		$threshold = $_POST['threshold'];
		$verifierId = mysqli_query($dbConnection, "SELECT company_id FROM companies WHERE company_name='" . $verifier . "'");
		if($verifierId && mysqli_num_rows($verifierId)){
			$verifierId = mysqli_fetch_array($verifierId);
			$verifierId = $verifierId['company_id'];
		} else {
			$verifierId = 0;
		}
		$addVerification = "INSERT INTO pending_verifications VALUES (null, $userId, $verifierId, $threshold, NOW())";
		$addVerification = mysqli_query($dbConnection, $addVerification);
		if($addVerification){
			$pendingId = mysqli_insert_id($dbConnection);
			$documentId = 0;
			if(isset($_SESSION['htmlString'])){
				$htmlString = addslashes($_SESSION['htmlString']);
				$addDocument = "INSERT INTO documents VALUES (null, $userId, $pendingId, '$htmlString')";
				$addDocument = mysqli_query($dbConnection, $addDocument);
				if($addDocument){
					$documentId = mysqli_insert_id($dbConnection);
				}
				unset($_SESSION['htmlString']);
			}
			if(isset($_SESSION['ciphertextData'])){
				$ciphertextData = $_SESSION['ciphertextData'];
				$addCiphertext = "INSERT INTO encrypted_text VALUES (null, $documentId, '$ciphertextData')";
				$addCiphertext = mysqli_query($dbConnection, $addCiphertext);
				unset($_SESSION['ciphertextData']);
			}
		} else {
			//Error message
		}
	} else {
		//Error -- missing fields
	}
	
	header('Location: account.php');
?>
