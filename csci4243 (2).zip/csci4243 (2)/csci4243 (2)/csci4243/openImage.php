<?php

	require_once('mysqli_connect.php');

	if(isset($_GET['documentId'])){
		$documentId = $_GET['documentId'];

		$htmlString = "SELECT private_image FROM documents WHERE document_id=" . $documentId;
		$htmlString = mysqli_query($dbConnection, $htmlString);

		if($htmlString && mysqli_num_rows($htmlString)){
			$row = mysqli_fetch_array($htmlString);
			echo $row['private_image'];
		}
	}
?>